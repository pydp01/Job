let jobs = JSON.parse(localStorage.getItem("jobs") || "[]");
let applications = JSON.parse(localStorage.getItem("applications") || "[]");

// Post a new job
function addJob(event) {
  event.preventDefault();
  const job = {
    id: Date.now(),
    title: title.value,
    company: company.value,
    location: location.value,
    description: description.value
  };
  jobs.push(job);
  localStorage.setItem("jobs", JSON.stringify(jobs));
  alert("Job posted!");
  window.location.href = "jobs.html";
}

// Show job listings
const jobList = document.getElementById("jobList");
if (jobList) {
  jobs.forEach(job => {
    jobList.innerHTML += `
      <div>
        <h3>${job.title} at ${job.company}</h3>
        <p>${job.location}</p>
        <a href="job.html?id=${job.id}">View Details</a>
      </div>
    `;
  });
}

// Show job details
const jobDetail = document.getElementById("jobDetail");
if (jobDetail) {
  const id = new URLSearchParams(location.search).get("id");
  const job = jobs.find(j => j.id == id);
  jobDetail.innerHTML = `
    <h2>${job.title}</h2>
    <h4>${job.company}</h4>
    <p>${job.location}</p>
    <p>${job.description}</p>
  `;
  document.getElementById("applyLink").href = `apply.html?id=${job.id}`;
}

// Submit an application
function submitApplication(e) {
  e.preventDefault();
  const id = new URLSearchParams(location.search).get("id");
  const app = {
    jobId: id,
    name: name.value,
    email: email.value,
    coverLetter: coverLetter.value
  };
  applications.push(app);
  localStorage.setItem("applications", JSON.stringify(applications));
  alert("Application submitted!");
  window.location.href = "index.html";
}

// Dashboard
const yourJobs = document.getElementById("yourJobs");
const yourApplications = document.getElementById("yourApplications");

if (yourJobs) {
  jobs.forEach(job => {
    yourJobs.innerHTML += `<li>${job.title} at ${job.company}</li>`;
  });
}
if (yourApplications) {
  applications.forEach(app => {
    const job = jobs.find(j => j.id == app.jobId);
    yourApplications.innerHTML += `<li>${job?.title || 'Unknown'} — Applied by ${app.name}</li>`;
  });
}

// Search
function searchJobs() {
  const term = document.getElementById("searchInput").value.toLowerCase();
  const filtered = jobs.filter(j => j.title.toLowerCase().includes(term));
  jobList.innerHTML = "";
  filtered.forEach(job => {
    jobList.innerHTML += `<div>
      <p>${job.location}</p>
      <h3>${job.title} at ${job.company}</h3>
      <a href="job.html?id=${job.id}">View</a>
    </div>`;
  });
}
